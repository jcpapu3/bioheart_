/*
  Bio-Heart (solo ECG) - Arduino Uno + AD8232 + HC-05
  Envia por Bluetooth 100 muestras por segundo, una por linea.

  Conexiones (como las tienes):
  AD8232:  OUTPUT -> A0 | 3.3V -> 3.3V | GND -> GND   (LO+ y LO- sin conectar)
  HC-05:   TXD -> D2 | RXD -> D3 | VCC -> 5V | GND -> GND
  Buzzer:  no se usa
*/

#include <SoftwareSerial.h>

SoftwareSerial bt(2, 3);  // RX (D2 <- TXD del HC-05), TX (D3 -> RXD del HC-05)

unsigned long lastSend = 0;

void setup() {
  Serial.begin(115200);
  bt.begin(9600);
}

void loop() {
  unsigned long now = millis();
  if (now - lastSend >= 10) {  // 100 Hz
    lastSend = now;
    int ecg = analogRead(A0);
    bt.println(ecg);
    Serial.println(ecg);
  }
}
